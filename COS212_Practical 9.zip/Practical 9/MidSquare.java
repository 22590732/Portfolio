//u22590732 - Nicolaas Johan Jansen van Rensburg
public class MidSquare extends HashFunction {

    public MidSquare(int n) {
        num = n;
    }

    public int hash(String input) {
        String convertedInput = stringToNum(input);
        long longInput = Long.parseLong(convertedInput);
        long squaredInput = longInput * longInput;
        String sSquaredInput = Long.toString(squaredInput);

        if (sSquaredInput.length() <= num) {
            return Integer.parseInt(sSquaredInput);
        }
        else {
            int start = (sSquaredInput.length() - num) / 2;
            int end = start + num;

            String sMiddle = sSquaredInput.substring(start, end);

            if (isValid(sMiddle, sSquaredInput) == true) {
                return Integer.parseInt(sMiddle);
            }
            else {
                sMiddle += "0";
                return Integer.parseInt(sMiddle);
            }
        }
    }

    private boolean isValid(String mid, String fullString) {
        int left = 0;
        int right = 0;

        int midIndex = fullString.indexOf(mid);
        int midLength = mid.length();



        for (int i = 0; i < midIndex; i++) {
            left++;
        }

        for (int i = midIndex + midLength; i < fullString.length(); i++) {
            right++;
        }



        if (left == right) {
            return true;
        }
        else {
            return false;
        }
    }

}
