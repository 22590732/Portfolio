//u22590732 - Nicolaas Johan Jansen van Rensburg
public class Hashmap {
    public HashFunction[] functions;
    public String[][] data;

    public Hashmap(int length, HashFunction[] funcs) {
        functions = funcs;

        data = new String[length][];
        for (int i = 0; i < length; i++) {
            data[i] = new String[0];
        }
    }

    public int hash(String val) {
        int total = 0;

        for (int i = 0; i < functions.length; i++) {
            total += functions[i].hash(val);
        }

        return total % data.length;
    }

    public boolean contains(String val) {
         int index = hash(val);

         for (int i = 0; i < data[index].length; i++) {
             if (data[index][i].equals(val)) {
                 return true;
             }
         }
        return false;
    }

    public void insert(String s) {
        if (contains(s)) {
            return;
        }

        int index = hash(s);
        String[] oldChain = data[index];
        String[] newChain = new String[oldChain.length + 1];

        for (int i = 0; i < oldChain.length; i++) {
            newChain[i] = oldChain[i];
        }

        newChain[newChain.length - 1] = s;
        data[index] = newChain;
    }

    public void remove(String s) {
        if (contains(s) == false) {
            return;
        }

        int index = hash(s);

        if (index == 1) {
            data[index] = new String[0];
        }

        String[] oldChain = data[index];
        String[] newChain = new String[oldChain.length - 1];

        int newIndex = 0;
        for (int i = 0; i < oldChain.length; i++) {
            if (oldChain[i].equals(s) == false) {
                newChain[newIndex++] = oldChain[i];
            }
        }

        data[index] = newChain;
    }

    public String toString() {
        StringBuilder sBuilder = new StringBuilder();

        sBuilder.append("[");

        for (int i = 0; i < data.length; i++) {
            if (i > 0) {
                sBuilder.append(";");
            }

            if (data[i].length > 0) {
                for (int j = 0; j < data[i].length; j++) {
                    if (j > 0) {
                        sBuilder.append(",");
                    }

                    sBuilder.append(data[i][j]);
                }
            }
        }

        sBuilder.append("]");
        return sBuilder.toString();
    }
};
