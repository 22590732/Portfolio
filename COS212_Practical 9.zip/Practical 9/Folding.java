//u22590732 - Nicolaas Johan Jansen van Rensburg
public class Folding extends HashFunction {
    public boolean shift;

    public Folding(int n, boolean s) {
        num = n;
        shift = s;
    }

    @Override
    public int hash(String input) {
        String convertedInput = stringToNum(input);

        StringBuilder padInput = new StringBuilder(convertedInput);
        int padLength = convertedInput.length();
        int rem = padLength % num;
        if (rem != 0) {
            int zeros = num - rem;

            for (int i = 0; i < zeros; i++) {
                padInput.append("0");
            }
        }

        String paddedInput = padInput.toString();

        int sum = 0;

        for (int i = 0; i < paddedInput.length(); i += num) {
            String partition = paddedInput.substring(i, i + num);
            int iPartition = Integer.parseInt(partition);

            if (!shift && (i / num) % 2 == 1) {
                int reversed = 0;
                int temp = iPartition;

                while (temp != 0) {
                    int digit = temp % 10;
                    reversed = reversed * 10 + digit;
                    temp /= 10;
                }

                iPartition = reversed;
            }

            sum += iPartition;

        }
        return sum;
    }
}
