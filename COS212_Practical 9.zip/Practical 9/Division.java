//u22590732 - Nicolaas Johan Jansen van Rensburg
public class Division extends HashFunction {

    public Division(int n) {
        num = n;
    }

    @Override
    public int hash(String input) {
        String convertedInput = stringToNum(input);

        long LongInput = Long.parseLong(convertedInput);
        int rem = (int) (LongInput % num);

        return rem;
    }
}
