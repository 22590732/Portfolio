//u22590732 - Nicolaas Johan Jansen van Rensburg
public class Extraction extends HashFunction {
    public Extraction(int n) {
        num = n;
    }

    @Override
    public int hash(String input) {
        String convertedInput = stringToNum(input);

        if (convertedInput.length() <= num) {
            return Integer.parseInt(convertedInput);
        }
        else {
            return Integer.parseInt(convertedInput.substring(convertedInput.length() - num));
        }
    }

}
