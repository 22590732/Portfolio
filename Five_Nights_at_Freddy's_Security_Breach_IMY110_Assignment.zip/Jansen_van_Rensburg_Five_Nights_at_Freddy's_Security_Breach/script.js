//Name: Nicolaas Johan
//Surname: Jansen van Rensburg
//Student Number: 22590732

var button = document.getElementById("submit");

button.onclick = function(){
	var email = document.getElementById("email").value;
	var name = document.getElementById("name").value;
	var lastName = document.getElementById("lastName").value;
	var country = document.getElementById("country").value;
	var zip = document.getElementById("zip").value;
	var city = document.getElementById("city").value;
	var address = document.getElementById("address").value;
	var cardNo = document.getElementById("card").value;
	var cvc = document.getElementById("cvc").value;

	if (email = "") {
		alert("please type in a valid email");
	}
	
	if (name = "") {
		alert("please type in your first name");
	}

	if (lastName == "") {
		alert("please type in your surname");
	}

	if (zip == "") {
		alert("please type in your zip code");
	}

	if (city == "") {
		alert("please type in your city name");
	}

	if (address == "") {
		alert("please type in a valid address");
	}

	if (card == "") {
		alert("please type in a valid card number");
	}

	if (cvc == "") {
		alert("please type in a valid cvc number");
	}
}