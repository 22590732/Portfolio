<template>
  <div class="hello">
    <h6>{{status}}</h6>
     <h6>{{data}}</h6>
     <button v-on:click="postReq">POST BUTTON</button>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        data: [ { "userId":"test"} ],
        status:"None"
      };
    },
    methods: {
      postReq: function() {
        this.status = "Post";
        const reqOptions = {
          method: 'POST',
          headers: {'Content-Type':'application/json; charset=UTF-8'},
          body: JSON.stringify({
            "userId":9001,
            "id":9999,
            "title":"testPost",
            "completed":true
          })
        }
        fetch("https://jsonplaceholder.typicode.com/todos", reqOptions)
        .then(response => response.json())
        .then(data => (this.data = data));
      }, 
    }
  }
</script>