<template>
  <div class="hello">
    <input type="text" name="inputField"/>

    <!--find a way to make this the only page 
    with status and data and 
    make it change according to the buttons pressed-->
    
     <GetComp/>
     <PostComp/>
     <PutComp/>
     <PatchComp/>
     <DelComp/>
     
  </div>
</template>

<script>

  import GetComp from './GetComp.vue'
  import PostComp from './PostComp.vue'
  import PutComp from './PutComp.vue'
  import PatchComp from './PatchComp.vue'
  import DelComp from './DelComp.vue'


  export default {
    name: 'App',
    components: {
      GetComp,
      PostComp,
      PutComp,
      PatchComp,
      DelComp
    }
  }
</script>