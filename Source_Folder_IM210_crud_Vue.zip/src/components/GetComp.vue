<template>
  <div class="hello">
    <h6>{{status}}</h6>
     <h6>{{data}}</h6>
     <button v-on:click="getReq">GET BUTTON</button>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        data: [ { "userId":"test"} ],
        status:"None"
      };
    },
    methods: {
      getReq: function() {
        this.status = "Get";
        fetch("https://jsonplaceholder.typicode.com/todos/12")
        .then(response => response.json())
        .then(data => (this.data = data));
      }
    }
  }
</script>