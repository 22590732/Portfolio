<template>
  <div class="hello">
    <h6>{{status}}</h6>
     <h6>{{data}}</h6>
     <button v-on:click="patchReq">PATCH BUTTON</button>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        data: [ { "userId":"test"} ],
        status:"None"
      };
    },
    methods: {
      patchReq: function() {
        this.status = "Patch";
        const reqOptions = {
          method: 'PATCH',
          headers: {'Content-Type':'application/json; charset=UTF-8'},
          body: JSON.stringify({"title":"testPatch"})
        }
        fetch("https://jsonplaceholder.typicode.com/todos/10", reqOptions)
        .then(response => response.json())
        .then(data => (this.data = data));
      }
    }
  }
</script>