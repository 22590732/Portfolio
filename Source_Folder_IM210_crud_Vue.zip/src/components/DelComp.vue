<template>
  <div class="hello">
    <h6>{{status}}</h6>
     <h6>{{data}}</h6>
     <button v-on:click="delReq">DELETE BUTTON</button>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        data: [ { "userId":"test"} ],
        status:"None"
      };
    },
    methods: {
      delReq: function() {
        this.status = "Delete";

        const reqOptions = {
          method: 'DELETE'
        }
        fetch("https://jsonplaceholder.typicode.com/todos/142", reqOptions)
        .then(response => response.json())
        .then(data => (this.data = data));
      }
    }
  }
</script>