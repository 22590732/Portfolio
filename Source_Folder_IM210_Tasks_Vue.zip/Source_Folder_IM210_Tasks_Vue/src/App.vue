<template>
  <div>
    <TaskAdd style="margin: 5px;"/>
    <TaskHolder style="margin: 5px;"/>
  </div>
</template>

<script>
  import TaskHolder from './components/TaskHolder.vue'
  import TaskAdd from './components/TaskAdd.vue'

  export default {
    name: 'App',
    components: {
      TaskHolder,
      TaskAdd
    }
  }
</script>

<style>
  body: {
    margin: 0;
    padding: 0;
  }

  div: {
    display: flex;
    margin: 0;
    padding: 0;
  }
</style>