<template>
	<div style="width: 220px; background-color: lightgrey;padding: 10px; border-radius: 10px; margin-right: 5px; font-family: Times New Roman; font-size: 20px;">
		<p>
			Connected to <b> {{getTask}} </b>
		</p>
		<input type="text" v-model="inputTask"/>
		<button @click="addTask(inputTask)">Add Task</button>
		<button @click="addCategory(inputTask)">Add Category</button>
	</div>
</template>

<script>
	import { store } from '../store.js'

	export default {
		name: 'TaskAdd',
		methods: {
			addTask(task) {
				store.addTask(task);
				this.inputTask = "";
			},
			addCategory(task) {
				store.addCategory(task);
				this.inputTask = "";
			}
		},
		computed: {
			getTask() {
				return store.getActiveTask().title;
			}
		},
		data() {
			return {
				inputTask:"",
			}
		}
	}
</script>

<style>
	button: {
		border-radius: 50px;
	}

	button:hover {
		background-color: grey;
	}
</style>