<template>
	<div @click="setActive(task.id)" style="width: auto; background-color: grey;padding: 10px;margin: 10px; border-radius: 15px;">
		<span style="color:white;font-size: 15pt; font-family: Comic Sans; font-style: oblique; font-weight: bold;">{{task.title}} Tasks</span>
		
		<TransitionGroup name="list" tag="ul">
			<TaskItem v-for="(item, index) in task.task" :key="index" :item="item"/>
		</TransitionGroup>
	</div>
</template>

<script>
	import { store } from '../store.js'
	import TaskItem from './TaskItem.vue'

	export default {
		name: 'TaskCategory',
		components: {
			TaskItem
		},
		props: ['task'],
		methods: {
			setActive(taskID) {
				store.setActiveTask(taskID);
			}
		}
	}
</script>

<style>
	.list-enter-active,
.list-leave-active {
  transition: all 0.5s ease;
}
.list-enter-from,
.list-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
</style>