<template>
	<div style="width: 170px; height: 50px; background-color: lightpink; margin: 10px;padding: 10px; font-size: 15px; display: flex; justify-content: space-around; align-items: center; font-family: 'Times New Roman'; border-radius: 50px;">
			{{item.details}}

			<button @click="deleteItem()">X</button>
	</div>
</template>

<script>
	import {store} from '../store.js'

	export default {
		name: 'TaskItem',
		props: ['item'],
		methods: {
			deleteItem() {
				const pos = this.item.details;
				store.deleteTask(pos);
			}
		}
	}
</script>

<style>
	button: {
		font-size: 500px;
		text-align: right;
	}
</style>