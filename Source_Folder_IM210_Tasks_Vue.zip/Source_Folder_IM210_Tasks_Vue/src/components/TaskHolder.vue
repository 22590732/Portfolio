<template>
	<div style=" display: flex; justify-content: space-around; width: auto; background-color: lightblue;padding: 10px; border-radius: 10px; margin-left: 5px;">
		<TaskCategory v-for="task in shareData.data" :key="task.id" :task="task"/>
	</div>
</template>

<script>
	import TaskCategory from './TaskCategory.vue'
	import { store } from '../store.js'

	export default {
		name: 'TaskHolder',
		components: {
			TaskCategory
		},
		data() {
			return {
				shareData: store.state,
			}
		}
	}
</script>