import { taskData } from './data.js';
import { reactive } from 'vue';

export const store = {
	state: {
		data: reactive(taskData),
	},
	getActiveTask() {
		return this.state.data.find((task)=>task.active);
	},
	setActiveTask(taskID) {
		this.state.data.map((task)=> {
			if (task.id === taskID) {
				task.active = true;
			}
			else {
				task.active = false;
			}
		})
	},
	addTask(task) {
		const currentTask = this.getActiveTask();
		currentTask.task.push({"details":task});
	},
	addCategory(task) {

		const newID = taskData.length;

		this.state.data.push({"id":newID, "title":task, "active":false, "task":[]});
	},
	deleteTask(pos) {

		const currentTask = this.getActiveTask().id;
		//alert(currentTask);

			for (let i = 0; i < this.state.data[currentTask].task.length; i++){
				if (this.state.data[currentTask].task[i].details === pos){
					this.state.data[currentTask].task.splice(i, 1);
				}
			}


	}
}